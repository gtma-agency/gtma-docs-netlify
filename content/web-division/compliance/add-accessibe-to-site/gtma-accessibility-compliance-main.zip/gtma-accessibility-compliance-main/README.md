# GTMA Accessibility + Compliance

Contributors: jrcreative

Tags: accessibility, compliance, accessibe, termly

License URI: https://gtma.agency/accessibility-compliance

Add Accessibility and Compliance to your WordPress site.

## Description
Add Accessibility and Compliance to your WordPress site. GTMA\'s accessibility and compliance packages can be enabled with this tool. Limited customizability can be achieved here, but for more options, contact your account manager at GTMA. Please let us know if you\'ve changed the way you handle personally identifiable information, and we will update your settings accordingly.
